# OnlineBookStore-Database-management

This is a database suitable for an online bookshop with namely 7 tables.<br />
BookInfo ---- has all details of the books(those may/may not be present in store)<br />
Inventory ----- has details of books present in store with coressponding quantity,price and suppliers<br />
Supplier ----- has the list of suppliers<br />
Purchase ------- has the entry of all purchases made in the shop <br />
Customer -------- stores the contact and name of customer<br />
Autdet ------- Contains details of Author including age,name,sex(the details are randomly genrated using a python script and real world authenticity is not present)<br />
log_pu_details ------contains the log of books which were purchased and by whom etc and it also contains details of any ordes if it was cancelled.<br />

triggeres and certain complex queries are mentioned in triggeres and query file.<br />

